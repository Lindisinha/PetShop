﻿using System;
using System.Reflection;
using System.Windows.Forms;

public class Empresa

{
    public string nomeFan = "";
    public string rzSocial;
    public double stCadastral;
    public string cpnj;
    public string telefone;
    public string dtInicio;
    public string rgTributario;
    public string endereco;
    public string cidade;
    public string estado;
    public double funcao;
    public string tipo;
    public string ptEmpresa;
    public string ntJuridica;
    public string nmProprietario;
    public string cpfPropie;
    

}